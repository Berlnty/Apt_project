import java.util.ArrayList;

public class Page_data {
  public ArrayList<String> buttons;
    Page_data(){
        buttons=new ArrayList<String
                >();

    }
}
